# SpamSms

Kumpulan Beberapa Script Spam Sms Buatan Para Mastah.

Saya Hanya Bantu Nyusun Agar Lebih Mudah Di Gunakan Saja.

Tutorial install di www.gebangkiidiw.com
